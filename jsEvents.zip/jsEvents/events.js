let table = document.getElementById("table-body");


let cells=[];
for(let i=0; i<5;i++){
    let row= document.createElement('tr');
    cells[i]=[];
    for (let j = 0; j < 5; j++) {
        let cell = document.createElement('td');
        cell.id=`cell_${i}_${j}`;
        cell.innerText=`cell ${i} ${j}`;

        cells[i][j]=cell;
        row.appendChild(cell);
    }
    table.appendChild(row);
}

// cell 0 0 click event

cells[0][0].innerText="click me"
cells[0][0].addEventListener('click',()=>{

    if(cells[0][0].innerText === "you clicked me"){
        cells[0][0].style.color="black";
        cells[0][0].innerText="clicked me";
        cells[0][0].style.backgroundColor="white";
    }else{
        cells[0][0].innerText="you clicked me";
        cells[0][0].style.backgroundColor="blue";
        cells[0][0].style.color="white";
    }
});



// cell 0 1 bouble click event

cells[0][1].innerText="double click me"
cells[0][1].addEventListener('dblclick',()=>{

    if(cells[0][1].innerText === "you double clicked me"){
        cells[0][1].style.color="black";
        cells[0][1].innerText="double clicked me";
        cells[0][1].style.backgroundColor="white";
    }else{
        cells[0][1].innerText="you double clicked me";
        cells[0][1].style.backgroundColor="pink";
    }
});

// cell 0 2 mousedown and mouseup event

cells[0][2].innerText="press the mouse"
cells[0][2].addEventListener('mousedown',()=>{

        cells[0][2].innerText="mouse is down";
        cells[0][2].style.backgroundColor="yellow";
    
});

cells[0][2].addEventListener('mouseup', ()=>{
     cells[0][2].style.color="black";
        cells[0][2].innerText="mouse is up";
        cells[0][2].style.backgroundColor="white";
});


//cell 0 3 mousemove 
cells[0][3].innerText="move mouse in me"
cells[0][3].addEventListener('mousemove', ()=>{
    cells[0][3].style.backgroundColor="green";
    cells[0][3].innerText="mousemove even is called!!";
})

//cell 0 4 mouseenter  , mouseleave
let timeoutId = null;

cells[0][4].innerText="enter mouse in me"
cells[0][4].addEventListener('mouseenter', ()=>{
   if(timeoutId){
    clearTimeout(timeoutId);
    timeoutId= null;
   }
    cells[0][4].style.backgroundColor="red";
    cells[0][4].innerText="mouseenter is called!!";
})


cells[0][4].addEventListener('mouseleave', ()=>{
    mouseenter_flag=false;
    cells[0][4].style.backgroundColor="purple";
    cells[0][4].innerText="mouseleave is called!!";
    
    timeoutId = setTimeout(()=>{
        cells[0][4].innerText="enter mouse in me";
        cells[0][4].style.backgroundColor="white";
    },2000);
})


//cell 1 0 contextmenu 
cells[1][0].innerText="right click me";
cells[1][0].addEventListener('contextmenu', ()=>{
    cells[1][0].style.backgroundColor="red";
    cells[1][0].innerText="contextmenu is called!!";
})


//cell 1 1 wheel 
cells[1][1].innerText="scroll mouse wheel in me"
cells[1][1].addEventListener('wheel', ()=>{
    cells[1][1].style.backgroundColor="orange";
    cells[1][1].style.borderRadius = "60%";
    cells[1][1].innerText= "wheel - mouse wheel scored in cell!!";
})

