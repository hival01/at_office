const express = require("express");
const router = express.Router();
const db = require("../config/database");

router.get("/:id", async (req, res) => {
  let applicant_id = req.params.id;
  console.log(applicant_id);

  const [basic_details] = await db.execute("select * from basic_details where applicant_id=(?)", [applicant_id]);
  const [education] = await db.execute(`select * from education where applicant_id=?` ,[applicant_id]);
  const [work_exp] = await db.execute(`select * from work_experience where applicant_id=?` ,[applicant_id]);
  const [languages] = await db.execute(`select * from applicant_language where applicant_id=?` , [applicant_id]);
  const [technologies] = await db.execute(`select * from applicant_technologies where applicant_id=?` , [applicant_id]);
  const [preferences] = await db.execute(`select * from preferences where applicant_id=?`, [applicant_id]);

  
  //   console.log(`rows is ${rows}`);
  //   console.log(`rows in  is ${rows[0]}`);

  //     const basic_details = rows[0];
  //   console.log(`basic details ${basic_details[0]}`);

  let data = {
    applicant_id,
    basic_details,
    education,
    work_exp,
    languages,
    technologies,
    preferences,
  };
  console.log(data);
  //console.log((data.basic_details[0].first_name));

  return res.render("updateForm", { data });
});

module.exports = router;
